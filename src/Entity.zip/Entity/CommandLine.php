<?php

namespace App\Entity;

use App\Repository\CommandLineRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CommandLineRepository::class)]
class CommandLine
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?int $quantity = null;

    #[ORM\ManyToOne]
    private ?Order $orders = null;

    #[ORM\ManyToOne]
    private ?Product $product = null;

    #[ORM\ManyToOne(inversedBy: 'commandline')]
    private ?Order $commandline = null;

    #[ORM\ManyToOne(inversedBy: 'commandline')]
    private ?Product $commandlines = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getQuantity(): ?int
    {
        return $this->quantity;
    }

    public function setQuantity(int $quantity): static
    {
        $this->quantity = $quantity;

        return $this;
    }

    public function getOrders(): ?Order
    {
        return $this->orders;
    }

    public function setOrders(?Order $orders): static
    {
        $this->orders = $orders;

        return $this;
    }

    public function getProduct(): ?Product
    {
        return $this->product;
    }

    public function setProduct(?Product $product): static
    {
        $this->product = $product;

        return $this;
    }

    public function getCommandline(): ?Order
    {
        return $this->commandline;
    }

    public function setCommandline(?Order $commandline): static
    {
        $this->commandline = $commandline;

        return $this;
    }

    public function getCommandlines(): ?Product
    {
        return $this->commandlines;
    }

    public function setCommandlines(?Product $commandlines): static
    {
        $this->commandlines = $commandlines;

        return $this;
    }
}
